package view;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import th.co.cdg.train.exam.bean.CategoryBean;
import th.co.cdg.train.exam.bean.ProductBean;
import th.co.cdg.train.exam.business.OnlineShopQueryLocal;
import th.co.cdg.train.exam.vm.CategoryVM;
import th.co.cdg.train.exam.vm.ProductVM;


@SessionScoped
@ManagedBean
public class IndexController {
	@EJB
	private OnlineShopQueryLocal onlineShopQueryLocal;

	@ManagedProperty(value = "#{categoryVM}")
	private CategoryVM categoryVM;

	@ManagedProperty(value = "#{productVM}")
	private ProductVM productVM;

	private List<CategoryBean> categoryBeans;

	private List<ProductBean> productBeans;

	private List<Integer> listView = Arrays.asList(5, 10);
	
	private int row;
	
	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	@PostConstruct
	public void init() {
		categoryVM.setCategoryCode("001");
		search();
	}

	public List<Integer> getListView() {
		return listView;
	}

	public void setListView(List<Integer> listView) {
		this.listView = listView;
	}

	public List<CategoryBean> getCategoryBeans() {

		if (categoryBeans == null) {
			categoryBeans = onlineShopQueryLocal.queryCategory();
		}
		return categoryBeans;
	}

	public OnlineShopQueryLocal getOnlineShopQueryLocal() {
		return onlineShopQueryLocal;
	}

	public void setOnlineShopQueryLocal(OnlineShopQueryLocal onlineShopQueryLocal) {
		this.onlineShopQueryLocal = onlineShopQueryLocal;
	}

	public List<ProductBean> getProductBeans() {
		/*if (productBeans == null) {
			productBeans = onlineShopQueryLocal.queryProductByCategoryCode("001");
		}*/
		return productBeans;
	}

	public void setProductBeans(List<ProductBean> productBeans) {
		this.productBeans = productBeans;
	}

	public void setCategoryBeans(List<CategoryBean> categoryBeans) {
		this.categoryBeans = categoryBeans;
	}

	public CategoryVM getCategoryVM() {
		return categoryVM;
	}

	public void setCategoryVM(CategoryVM categoryVM) {
		this.categoryVM = categoryVM;
	}

	public ProductVM getProductVM() {
		return productVM;
	}

	public void setProductVM(ProductVM productVM) {
		this.productVM = productVM;
	}

	public void search() {

	
		final List<ProductBean> productBeans = onlineShopQueryLocal.queryProductByCategoryCode(categoryVM.getCategoryCode());
		setProductBeans(productBeans);
	}

	public void setCount(int i) {

	}

}
