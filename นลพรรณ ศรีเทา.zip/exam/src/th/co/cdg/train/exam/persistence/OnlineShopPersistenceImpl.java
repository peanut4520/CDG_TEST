package th.co.cdg.train.exam.persistence;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import th.co.cdg.train.exam.entity.Category;

/**
 * Session Bean implementation class OnlineShopPersistence
 */
@Stateless
@LocalBean
public class OnlineShopPersistenceImpl implements OnlineShopPersistenceLocal {
	@PersistenceContext(unitName = "trainexam")
	private EntityManager em;

	/**
	 * Default constructor.
	 */
	public OnlineShopPersistenceImpl() {
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public List<Category> queryCategory() {
		final String sql = "select category_code, category_name from category order by category_code";
		Query query = em.createNativeQuery(sql, Category.class);
		return query.getResultList();
	}

}
