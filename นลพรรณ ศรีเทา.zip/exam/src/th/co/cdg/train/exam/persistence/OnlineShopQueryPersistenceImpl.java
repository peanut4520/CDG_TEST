package th.co.cdg.train.exam.persistence;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import th.co.cdg.train.exam.entity.Category;
import th.co.cdg.train.exam.entity.Product;

/**
 * Session Bean implementation class OnlineShopQueryPersistence
 */
@Stateless
@LocalBean
public class OnlineShopQueryPersistenceImpl implements OnlineShopQueryPersistenceLocal {
	@PersistenceContext(unitName = "trainexam")
	private EntityManager em;

	/**
	 * Default constructor.
	 */
	public OnlineShopQueryPersistenceImpl() {

	}

	@Override
	public List<Category> queryCategory() {
		final String sql = "select category_code, category_name from category order by category_code";
		Query query = em.createNativeQuery(sql, Category.class);
		return query.getResultList();
	}

	@Override
	public List<Product> queryProductByCategoryCode(String id) {
		final String sql = "select s from Product s where s.category.categoryCode = :category_code ";
		Query query = em.createQuery(sql);
		query.setParameter("category_code", id);
		

		return query.getResultList();
	}

}
