package th.co.cdg.train.exam.persistence;

import java.util.List;

import javax.ejb.Local;

import th.co.cdg.train.exam.entity.Category;
import th.co.cdg.train.exam.entity.Product;

@Local
public interface OnlineShopQueryPersistenceLocal {
	List<Category> queryCategory() ;
	List<Product> queryProductByCategoryCode(String id);
	

}
