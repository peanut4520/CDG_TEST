package th.co.cdg.train.exam.vm;
// Generated Jul 3, 2018 11:08:13 AM by Hibernate Tools 5.2.10.Final

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SessionScoped
@ManagedBean
public class CategoryVM implements java.io.Serializable {

	private String categoryCode;
	private String categoryName;

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public void reset() {
		setCategoryName(null);
	}

}
