package th.co.cdg.train.exam.business;

import java.util.List;

import javax.ejb.Remote;

import th.co.cdg.train.exam.bean.CategoryBean;
import th.co.cdg.train.exam.bean.CustomerBean;
import th.co.cdg.train.exam.bean.OrderBean;
import th.co.cdg.train.exam.bean.ProductBean;

@Remote
public interface OnlineShopQueryRemote {
	List<CategoryBean> queryCategory();

	List<ProductBean> queryProductByCategoryCode(String str1);

	CustomerBean queryCustomerById(String str1);

	OrderBean queryPrintOrder(String str1);
}
