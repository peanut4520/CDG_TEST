package th.co.cdg.train.exam.business;

import javax.ejb.Local;

@Local
public interface OnlineShopQueryLocal extends OnlineShopQueryRemote {

}
