package th.co.cdg.train.exam.business;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import th.co.cdg.train.exam.bean.CustomerBean;
import th.co.cdg.train.exam.bean.OrderBean;

/**
 * Session Bean implementation class OnlineShopBusiness
 */
@Stateless
@LocalBean
public class OnlineShopBusinessImpl implements OnlineShopBusinessRemote, OnlineShopBusinessLocal {

    /**
     * Default constructor. 
     */
    public OnlineShopBusinessImpl() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public OrderBean makeOrder(OrderBean ord) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CustomerBean insertCustomer(CustomerBean cus) {
		// TODO Auto-generated method stub
		return null;
	}

}
