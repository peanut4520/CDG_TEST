package th.co.cdg.train.exam.business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import th.co.cdg.train.exam.bean.CategoryBean;
import th.co.cdg.train.exam.bean.CustomerBean;
import th.co.cdg.train.exam.bean.OrderBean;
import th.co.cdg.train.exam.bean.ProductBean;
import th.co.cdg.train.exam.entity.Product;
import th.co.cdg.train.exam.persistence.OnlineShopQueryPersistenceLocal;

/**
 * Session Bean implementation class OnlineShopQuery
 */
@Stateless
@LocalBean
public class OnlineShopQueryImpl implements OnlineShopQueryRemote, OnlineShopQueryLocal {
	@EJB
	private OnlineShopQueryPersistenceLocal hrQueryPersistenceLocal;

	/**
	 * Default constructor.
	 */
	public OnlineShopQueryImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<CategoryBean> queryCategory() {
		List<th.co.cdg.train.exam.entity.Category> categorys = hrQueryPersistenceLocal.queryCategory();
		if (categorys != null && !categorys.isEmpty()) {
			List<CategoryBean> categoryBeans = new ArrayList<CategoryBean>();
			for (th.co.cdg.train.exam.entity.Category department : categorys) {
				CategoryBean departmentBean = new CategoryBean();
				departmentBean.setCategoryCode(department.getCategoryCode());
				departmentBean.setCategoryName(department.getCategoryName());
				categoryBeans.add(departmentBean);
			}

			return categoryBeans;
		}

		return null;
	}

	@Override
	public List<ProductBean> queryProductByCategoryCode(String categoryId) {

		List<Product> products = hrQueryPersistenceLocal.queryProductByCategoryCode(categoryId);
		int i = 0;

		if (products != null && !products.isEmpty()) {
			List<ProductBean> productBeans = new ArrayList<ProductBean>();
			for (Product p : products) {
				//i++;
				ProductBean productBean = new ProductBean();
				productBean.setProductCode(p.getProductCode());
				productBean.setProductName(p.getProductName());
				productBean.setDetail(p.getDetail().substring(0,50));
				productBean.setPrice(p.getPrice().intValue());

				

				productBeans.add(productBean);
			}
			return productBeans;
		}

		return null;
	}

	@Override
	public CustomerBean queryCustomerById(String str1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderBean queryPrintOrder(String str1) {
		// TODO Auto-generated method stub
		return null;
	}

}
