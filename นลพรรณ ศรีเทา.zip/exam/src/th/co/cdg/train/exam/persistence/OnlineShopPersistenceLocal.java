package th.co.cdg.train.exam.persistence;

import java.util.List;

import javax.ejb.Local;

import th.co.cdg.train.exam.entity.Category;

@Local
public interface OnlineShopPersistenceLocal {
	List<Category> queryCategory() ;
}
